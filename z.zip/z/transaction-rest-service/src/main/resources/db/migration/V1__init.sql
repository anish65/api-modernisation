CREATE TABLE "txn"."customer_detail" (
    "id" UUID PRIMARY KEY NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "cif_id" CHARACTER VARYING NOT NULL,
    "first_name" CHARACTER VARYING NOT NULL,
    "last_name" CHARACTER VARYING NOT NULL
);