package com.zand.system.transactionrestservice.controller;

import com.zand.system.common.messaging.kafka.message.FundTransferRQMessage;
import com.zand.system.common.messaging.kafka.message.TestMessage;
import com.zand.system.transactionrestservice.entity.AccountDetail;
import com.zand.system.transactionrestservice.messaging.producer.FundTxnPublisher;
import com.zand.system.transactionrestservice.repository.AccountDetailRepository;
import com.zand.system.transactionrestservice.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;

@RestController
@RequiredArgsConstructor
public class TestController {

    @Autowired
    TransactionService transactionService;

    @Autowired
    private final FundTxnPublisher fundTxnPublisher;

    @Autowired
    AccountDetailRepository accountDetailRepository;

    @PostMapping("/kafka")
    @ResponseStatus(HttpStatus.OK)
    public String doDebitTransaction(@Validated @RequestBody String message) {
        TestMessage testMessage = new TestMessage();
        testMessage.setMessage(message);
        fundTxnPublisher.publish(new FundTransferRQMessage( "fundTransferRefNo",
                "fundTransferRQ.getCifId()",
                "fundTransferRQ.getFromAccountId()",
                "fundTransferRQ.getToAccountId()",
                new BigDecimal("100.00"),
                "fundTransferRQ.getCurrency().name()",
                "fundTransferRQ.getDescription()",
                "transactionType"));
        return "Success";
    }

    @PostMapping("/testAccount")
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<AccountDetail> doDebitTransaction(@RequestBody AccountDetail accountDetail) {
        return accountDetailRepository.save(accountDetail);
    }
}
